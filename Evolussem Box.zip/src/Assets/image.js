module.exports = {
    Evolussem_logo: require("../Assets/Images/Evolussem_logo.png"),
    back_evo: require("../Assets/Images/back_evo.png"),
    button2_red2: require("../Assets/Images/button2_red2.png"),
    button2_green2: require("../Assets/Images/button2_green2.png"),
    button3: require("../Assets/Images/button3.png"),
    button4: require("../Assets/Images/button4.png"),
    button_notice: require("../Assets/Images/button_notice.png"),
    button2_red: require("../Assets/Images/button2_red.png"),
    
}