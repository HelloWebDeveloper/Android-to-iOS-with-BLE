//---------- imports

// react
import React, { useEffect } from "react";
import {
    Image,
    ImageBackground,
    LogBox,
    ScrollView,
    Text,
    TextInput,
    TouchableOpacity,
    View,
    NativeEventEmitter,
    NativeAppEventEmitter,
    NativeModules,
    Alert,
    BackHandler
} from "react-native";

// images
import {
    back_evo,
    button_notice,
    button2_red2,
    button2_green2,
    button3,
    button4,
    button2_red
} from "../Assets/image";

// lib
import {
    BleManager,
    Device,
    Service,
    Characteristic,
    Descriptor,
    BleError,
    BleErrorCode,
    LogLevel,
} from 'react-native-ble-plx';
// import BleManager from 'react-native-ble-manager';


// success
import BluetoothStateManager from 'react-native-bluetooth-state-manager';
import BluetoothDevices from "react-native-bluetooth-devices";
// utils
import { Slider } from "../Utils/Slider";


// volume 
import SystemSetting from 'react-native-system-setting'
//---------- main component
const manager = new BleManager()


const Home = ({ navigation }) => {

    //---------- state

    const [formValue, setFormValue] = React.useState(0);
    const [isVisible, setIsVisible] = React.useState(false);
    const [isConnected, setIsConnected] = React.useState(false);
    const [bluStatus, setBluStatus] = React.useState(false)
    const [isConfigVisible, setIsConfigVisible] = React.useState(false);
    const [bluList, setBluList] = React.useState([]);
    const [bluList1, setBluList1] = React.useState([]);
    const [connectDeviceUuid, setConnectUui] = React.useState()

    //---------- life cycles

    React.useEffect(() => {
        BackHandler.addEventListener('hardwareBackPress',
            handelCloseApp);
        getBlueToothStatus()
        getConnectedDisconnectedDeviceStatus()
        if (bluStatus && isVisible) {
            startScan()

        } else {
            manager.stopDeviceScan();
            setBluList1([])
            setBluList([])
        }
        //get the current volume
        SystemSetting.getVolume().then((volume) => {
            console.log('Current volume is ' + volume);
            setFormValue(volume * 100)

            SystemSetting.setVolume(parseFloat(volume, { showUI: true }));
        });
      
    }, [isVisible, bluStatus])

    // change the volume
    const handleVolume = (value) => {
        setFormValue(value)

        let volume_in_percent = parseInt(value) / 10

        if (parseInt(volume_in_percent) === 10) {

            volume_in_percent = `1`
        } else if (parseInt(value) < 10) {

            volume_in_percent = `0.1`
        } else {

            volume_in_percent = `0.${parseInt(volume_in_percent)}`
        }

        SystemSetting.setVolume(parseFloat(volume_in_percent, { showUI: true }));
    }

    const handleBleManager = async () => {

        // console.log('-=-=-=-=', BleManager())
        const manager = new BleManager()


        console.log('                   1    ')
        manager.startDeviceScan()

        console.log('                   2    ')
        await manager.state().then(res => {

            console.log('response -=-=-=--=-=>', res)

        }).catch(e => {
            console.log('error -=-=->', e)
        })
        // await BleManager.start({ showAlert: false, restoreIdentifierKey: '', queueIdentifierKey: '' }).then(() => {
        //     // Success code
        //     console.log("Module initialized");
        // });

        // await BleManager.scan([], 5, true).then(() => {
        //     // Success code
        //     console.log("Scan started");
        // });
    }


    const startScan = () => {
        manager.startDeviceScan(null, null,
            async (error, device) => {
                // setDisplaText('Scanning...');
                if (error) {

                    console.log('-=-=--=error->', error)
                    // manager.stopDeviceScan();
                }

                if (device.name) {

                    console.log('-=-=-=>', bluList)
                    console.log('-=-=-=>', bluList1)
                    handleCallBackAfterGetNewDevice(device)
                }
            },);
    };
    let array = bluList?.length > 0 ? bluList : []
    let array1 = bluList1?.length > 0 ? bluList1 : []

    useEffect(() => {
        array = bluList?.length > 0 ? bluList : []
        array1 = bluList1?.length > 0 ? bluList1 : []
    }, [bluList])
    const handleCallBackAfterGetNewDevice = (device) => {

        if (!array?.includes(device.name)) {

            array.push(device.name)
            array1.push({ name: device.name, id: device.id })

            setBluList(array);
            setBluList1(array1);

            // setBluList([...bluList, device.name]);
            // setBluList1([...bluList1, { name: device.name, id: device.id }]);
        }
    }

    const getBlueToothStatus = () => {

        BluetoothStateManager.onStateChange((bluetoothState) => {
            if (bluetoothState === 'PoweredOn') {
                setBluStatus(true)
            } else {

                setBluStatus(false)
                alert("veuillez activer le bluetooth")
            }
            
        }, true /*=emitCurrentState*/);
    }

    const getConnectedDisconnectedDeviceStatus = () => {
        // get connected device on change state

        BluetoothDevices.startScan()

        // "onConnectedDevices"
        // "BleManagerDiscoverPeripheral"
        BluetoothDevices.addEventListener("onConnectedDevices", (res) => {
            console.log("=-=---res", res)
            //   BluetoothDevices.disconnect()
        })

    }


    const connectDevice = deviceId => {
        console.log('deviceIddeviceId=', deviceId);
        setConnectUui(deviceId)
        // BluetoothDevices.connectToDevice(deviceId)
        manager.stopDeviceScan();
        manager.connectToDevice(deviceId).then(async device => {
            console.log('device=--=', device);
            await device.discoverAllServicesAndCharacteristics();
            manager.stopDeviceScan();
            setBluList1([])
            setBluList([])
            device.services().then(async service => {
                for (const ser of service) {
                    ser.characteristics().then(characteristic => {
                        //   getCharacteristics([...characteristics, characteristic]);
                        console.log('characteristic', characteristic[0]);
                        setIsConnected(!isConnected)
                        // getConnectedDisconnectedDeviceStatus()
                    });
                }
            });
        });
    };
    const disConnectDevices = () => {
       const abs= manager.cancelDeviceConnection(connectDeviceUuid)
console.log('abc',abs);
setIsConnected(!isConnected)
    }
    const handelCloseApp = () => {


        Alert.alert("Faemer l'applocation", "Voulez vous quitter l'application ?", [

            {
                text: "Oui",
                onPress: () => {
                    BackHandler.exitApp()
                },
                // style: 'cancel'

            },
            {
                text: "Non", onPress: () => {

                    null
                }
            }
        ]);
    }
    //---------- main view
    return (

        <ImageBackground
            source={back_evo}
            style={{
                flex: 1,
                paddingTop: 50,
                paddingHorizontal: 20
            }}
        >

            {
                //---------- top section
            }

            <View
                style={{ flexDirection: 'row' }}
            >

                {
                    //---------- bluetooth
                }
                <TouchableOpacity
                    onPress={() => setIsVisible(!isVisible)}
                    style={{
                        alignItems: "center",
                        justifyContent: "center",
                        height: 50,
                        width: '30%'

                    }}
                >
                    <ImageBackground
                        style={{
                            width: '100%',
                            height: '100%',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}
                        resizeMode="contain"
                        source={button4}
                    >

                        <Text
                            style={{ fontSize: 18, textAlign: "center" }}
                        >
                            Bluetooth
                        </Text>
                    </ImageBackground>
                </TouchableOpacity>

                {
                    //---------- connect / disconnect
                }
                <TouchableOpacity
                    onPress={() => {
                        // setIsConnected(!isConnected)
                        isConnected && disConnectDevices()

                    }}
                    style={{
                        alignItems: "center",
                        justifyContent: "center",
                        height: 50,
                        width: '70%',
                    }}
                >
                    <ImageBackground
                        source={
                            isConnected ?
                                button2_green2
                                :
                                button2_red2
                        }
                        style={{
                            width: '100%',
                            height: '100%',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}
                        resizeMode="contain"
                    >

                        <Text
                            style={{ fontSize: 18, textAlign: "center" }}
                        >
                            {
                                isConnected ?
                                    'Connecte`'
                                    :
                                    'Non Connecte`'
                            }

                        </Text>
                    </ImageBackground>
                </TouchableOpacity>
            </View>

            {
                //---------- config sectoin
            }
            {
                isConfigVisible &&
                <View
                    style={{
                        width: '100%',
                        alignItems: 'center',
                        marginVertical: 10,
                    }}
                >
                    <Text
                        style={{
                            color: "#fff",
                            fontSize: 18,
                            fontWeight: '500'
                        }}
                    >
                        Parametres Bluetooth
                    </Text>
                    <Text
                        style={{
                            color: "#fff",
                            fontSize: 16,
                        }}
                    >
                        Ajouter un chiffre derriere le nom du Bluetooth
                    </Text>

                    <View
                        style={{
                            flexDirection: 'row',
                            marginVertical: 10
                        }}
                    >
                        <TextInput
                            style={{
                                width: '50%',
                                backgroundColor: '#fff',
                                color: '#000',
                                paddingHorizontal: 5,
                                marginRight: 10,
                                borderColor: "orange",
                                borderWidth: 3,
                                borderRadius: 5,
                                fontSize: 17
                            }}
                            maxLength={3}
                            keyboardType="number-pad"
                            placeholder={'5 chiffres max.'}
                            placeholderTextColor={"#000"}
                            onChangeText={(text) => {
                                console.log('typ', text);
                                if (parseInt(text) <= 100 || parseInt(text?.length) === 0) {

                                    text && setFormValue(parseInt(parseInt(text)))
                                }
                                else {
                                    alert("please enter valid number")
                                }
                            }
                            }
                        />
                        <TouchableOpacity
                            onPress={() => {
                                setIsConfigVisible(!isConfigVisible)
                            }}
                            style={{
                                alignItems: "center",
                                justifyContent: "center",
                                marginRight: 20,
                                height: 50,
                                width: '20%'
                            }}
                        >

                            <ImageBackground
                                source={button3}
                                style={{
                                    width: '100%',
                                    height: '100%',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                }}
                                resizeMode="contain"
                            >

                                <Text
                                    style={{
                                        fontSize: 20,
                                        textAlign: "center",
                                        fontWeight: '400',
                                    }}
                                >
                                    ok
                                </Text>

                            </ImageBackground>
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity
                        onPress={() => {
                            setIsConfigVisible(false)
                        }}
                        style={{
                            alignItems: "center",
                            justifyContent: "center",
                            marginTop: 10,
                            marginRight: 20,
                            height: 50,
                            width: '50%'
                        }}
                    >

                        <ImageBackground
                            source={button2_red}
                            style={{
                                width: '100%',
                                height: '100%',
                                justifyContent: 'center',
                                alignItems: 'center'
                            }}
                            resizeMode="contain"
                        >

                            <Text
                                style={{
                                    fontSize: 20,
                                    textAlign: "center",
                                    fontWeight: '400',
                                }}
                            >
                                Annuler
                            </Text>

                        </ImageBackground>
                    </TouchableOpacity>

                </View>
            }

            {
                //---------- list of bluetooth
            }
            {
                isVisible &&
                <ScrollView
                    style={{ backgroundColor: "#000" }}
                >

                    {
                        bluList1.map((item, indx) => {
                            return (

                                <TouchableOpacity
                                    key={indx}
                                    onPress={() => { setIsVisible(!isVisible); connectDevice(item.id) }}
                                >

                                    <Text
                                        style={{
                                            color: "#fff",
                                            fontSize: 20,
                                            textAlign: "center",
                                            paddingVertical: 10
                                        }}
                                    >
                                        {item.name}
                                    </Text>
                                </TouchableOpacity >

                            )
                        })
                    }
                </ScrollView>
            }

            {
                //---------- slider
            }
            <>
                {
                    //---------- reglage title
                }
                <View
                    style={{
                        flexDirection: "row",
                        marginTop: 20,
                        alignItems: "center"
                    }}
                >
                    <Text
                        style={{
                            color: "#fff",
                            fontSize: 20,
                            marginRight: 10
                        }}
                    >
                        Reset reglage d'usine:
                    </Text>

                    <TouchableOpacity
                        style={{
                            alignItems: "center",
                            justifyContent: "center",
                            height: 50,
                            width: '20%'
                        }}
                        onPress={() => {

                            Alert.alert("", "Envoyer le nouveau reglage au boitier \n Etes vous sur ?", [

                                {
                                    text: "Oui",
                                    onPress: () => {
                                        null
                                    },
                                    style: 'cancel'

                                },
                                {
                                    text: "Non", onPress: () => {

                                        null
                                    }
                                }
                            ]);
                        }}
                    >
                        <ImageBackground
                            source={button3}
                            style={{
                                width: '100%',
                                height: '100%',
                                justifyContent: 'center',
                                alignItems: 'center'
                            }}
                            resizeMode="contain"
                        >
                            <Text
                                style={{
                                    fontSize: 20,
                                    textAlign: "center",
                                    fontWeight: '600'
                                }}
                            >
                                Ok
                            </Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>

                <Text
                    style={{
                        color: "#fff",
                        fontSize: 20,
                        marginRight: 10,
                        textAlign: "center",
                        marginTop: 20
                    }}
                >
                    reglage :{formValue}
                </Text>

                {
                    //---------- main slider
                }
                <View
                    style={{
                        flexDirection: "row",
                        alignItems: "center"
                    }}
                >
                    <Text
                        style={{
                            color: "#fff",
                            fontSize: 20,
                            marginTop: 20
                        }}
                    >
                        0
                    </Text>

                    <Slider min={0}
                        max={100}
                        step={4}
                        valueOnChange={value => handleVolume(value)}
                        initialValue={formValue}
                        knobColor='#e0dada'
                        valueLabelsBackgroundColor='black'
                        inRangeBarColor='#4a4848'
                        outOfRangeBarColor='#1d71f0'
                        showRangeLabels={false}
                        // styleSize={70}

                        containerStyle={{
                            height: 70,
                            width: "108%"
                        }}
                    />
                    <Text
                        style={{
                            color: "#fff",
                            fontSize: 20,
                            marginTop: 20
                        }}
                    >
                        100
                    </Text>

                </View>

                <Text
                    style={{
                        color: "#fff",
                        fontSize: 20,
                        textAlign: "center"
                    }}
                >
                    reglage Actuel : -----
                </Text>
            </>

            {
                //---------- middle section
            }
            <>
                <View
                    style={{
                        flexDirection: "row",
                        marginTop: 20,
                        alignItems: "center",
                        justifyContent: "space-between",
                        marginRight: 10
                    }}
                >
                    <Text
                        style={{
                            color: "#fff",
                            fontSize: 20,
                            marginRight: 10
                        }}
                    >
                        Envoyer le reglage :
                    </Text>

                    <TouchableOpacity
                        style={{
                            alignItems: "center",
                            justifyContent: "center",
                            height: 50,
                            width: '20%'
                        }}
                        onPress={() => {
                            Alert.alert("", "Envoyer le nouveau reglage au boitier \n Etes vous sur ?", [

                                {
                                    text: "Oui",
                                    onPress: () => {
                                      setFormValue(50)
                                    },
                                    style: 'cancel'

                                },
                                {
                                    text: "Non", onPress: () => {

                                        null
                                    }
                                }
                            ]);
                        }}
                    >
                        <ImageBackground
                            source={button3}
                            style={{
                                width: '100%',
                                height: '100%',
                                justifyContent: 'center',
                                alignItems: 'center'
                            }}
                            resizeMode="contain"
                        >

                            <Text
                                style={{
                                    fontSize: 20,
                                    textAlign: "center",
                                    fontWeight: '600'
                                }}
                            >
                                Ok
                            </Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>

                <View
                    style={{
                        flexDirection: "row",
                        marginTop: 20,
                        alignItems: "center",
                        justifyContent: "space-between",
                        marginRight: 10
                    }}
                >
                    <Text
                        style={{
                            color: "#fff",
                            fontSize: 20,
                            marginRight: 10
                        }}
                    >
                        Boitier active :
                    </Text>

                    <TouchableOpacity
                        style={{
                            alignItems: "center",
                            justifyContent: "center",
                            height: 50,
                            width: '20%'
                        }}
                    >
                        <ImageBackground
                            source={button3}
                            style={{
                                width: '100%',
                                height: '100%',
                                justifyContent: 'center',
                                alignItems: 'center'
                            }}
                            resizeMode="contain"
                        >

                            <Text
                                style={{
                                    fontSize: 20,
                                    textAlign: "center",
                                    fontWeight: '600'
                                }}
                            >
                                Non
                            </Text>
                        </ImageBackground>
                    </TouchableOpacity>
                </View>
            </>

            {
                //---------- bottom section
            }
            <View
                style={{
                    flexDirection: "row",
                    justifyContent: "center",
                    marginVertical: 20
                }}
            >

                {
                    //---------- left btn
                }
                <TouchableOpacity
                    style={{
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 20,
                        height: 50,
                        width: '30%'
                    }}
                    onPress={() => {
                        handelCloseApp()
                        // navigation.goBack()
                    }}
                >
                    <ImageBackground
                        source={button4}
                        style={{
                            width: '100%',
                            height: '100%',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}
                        resizeMode="contain"
                    >

                        <Text
                            style={{
                                fontSize: 20,
                                textAlign: "center",
                                fontWeight: '400',
                            }}
                        >
                            Fermer
                        </Text>
                    </ImageBackground>

                </TouchableOpacity>

                {
                    //---------- right btn
                }
                <TouchableOpacity
                    onPress={() => {
                        setIsConfigVisible(!isConfigVisible)
                    }}
                    style={{
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: 20,
                        height: 50,
                        width: '30%'
                    }}
                >
                    <ImageBackground
                        source={button4}
                        style={{
                            width: '100%',
                            height: '100%',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}
                        resizeMode="contain"
                    >

                        <Text
                            style={{
                                fontSize: 20,
                                textAlign: "center",
                                fontWeight: '400',
                            }}
                        >
                            Config
                        </Text>

                    </ImageBackground>
                </TouchableOpacity>

            </View>

            {
                //---------- show pdf btn
            }
            <View
                style={{
                    width: '100%',
                }}
            >

                <TouchableOpacity

                    onPress={() => {
                        navigation.navigate('WebViewScreen')
                    }}
                    style={{
                        alignItems: "center",
                        justifyContent: "center",
                        height: 65,
                    }}
                >
                    <ImageBackground
                        source={button_notice}
                        style={{
                            width: '100%',
                            height: '100%',
                            justifyContent: 'center',
                            paddingLeft: 15
                        }}
                        resizeMode="contain"
                    >

                        <Text
                            style={{
                                fontSize: 20,
                                textAlign: "center",
                                fontWeight: '400',
                            }}
                        >
                            Manuel d'utilsation
                        </Text>

                    </ImageBackground>
                </TouchableOpacity>

            </View>

        </ImageBackground>
    )
}

export default Home;

const data = [
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
    "hiu-090-9ihihhkhjh",
]